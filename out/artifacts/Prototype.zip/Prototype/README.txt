Preloaded Login Information:
-Username, Password
-Billing, 123
-Staff, 123
-Nurse, 123
-Doctor, 123

To create a patient login to staff, fill in feilds and click "cheak in"
Then login to any other role and use the search feild to search for the patient you created.

NOTE: Warnings and user feedback is still in progress so if a search fails you will not be notifyed, and nothing will happen,
as well as information entering is not pattern checked yet so make sure to enter the DOB as 00/00/000

Link to Code repo:https://github.com/ADocchio/C.A.R.E.S